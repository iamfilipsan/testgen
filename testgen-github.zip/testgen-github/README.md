# TESTGEN — English Test Generator

English test generator for Czech gymnasium (Prima–Oktáva, A1–B2+).

## Deploy

1. Fork this repo
2. Go to **Settings → Pages → Source → GitHub Actions**
3. Push any change to `main` — auto-deploys

## Usage

Open the deployed URL, enter your Anthropic API key (stored locally in browser, never sent anywhere except Anthropic directly).

## Stack

Single HTML file. React via CDN. No build step.
